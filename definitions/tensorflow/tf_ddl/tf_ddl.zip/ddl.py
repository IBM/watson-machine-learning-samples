# *****************************************************************
#
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2018, 2019. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# *****************************************************************

# Integration of DDL in Tensorflow scripts

# This Python module exports the following functions:
# - num_hosts(): number of hosts deployed
# - rank(): MPI rank number assigned to this process
# - size(): total number of MPI ranks (= number of GPUs)
# - local_rank(): id of GPU used by this process

# - init(options): initialize this module
# - bcast(init_val): broadcast initial value
# - allreduce_n(grads): DDL-reduces all gradient tensors in one go
# - grads_reduce(grads_and_vars):

import json
import os
import sys
import tensorflow as tf
import pyddl
from tensorflow.python.ops.variables import RefVariable
from tensorflow.python.distribute import cross_device_ops as cross_device_ops_lib
from tensorflow.python.distribute import cross_device_utils as cross_device_utils_lib
from tensorflow.python.training import distribution_strategy_context
from tensorflow.python.client import device_lib
from tensorflow.python.eager import context

# Design decision: get all MPI data via env NOT from ddl_MDR.init()!

mpi_init_status = True

# Get some MPI environment variables values:
mpi_vars = { 'OMPI_COMM_WORLD_SIZE':0,
             'OMPI_COMM_WORLD_LOCAL_SIZE':0,
             'OMPI_COMM_WORLD_RANK':0,
             'OMPI_COMM_WORLD_LOCAL_RANK':0 }

# Ensure all the necessary ENV variables are available;
# else don't initialize DDL & restrict DDL API invocations.
for var in mpi_vars:
    val = os.getenv(var)
    if val is None:
        mpi_init_status = False
        break;
    mpi_vars[var] = val

if mpi_init_status:
    #Get as number:
    world_size = int(mpi_vars['OMPI_COMM_WORLD_SIZE'])
    local_size = int(mpi_vars['OMPI_COMM_WORLD_LOCAL_SIZE'])
    world_rank = int(mpi_vars['OMPI_COMM_WORLD_RANK'])
    rank_local = int(mpi_vars['OMPI_COMM_WORLD_LOCAL_RANK'])

    # Get any options to configure DDL:
    DDL_OPTIONS = os.getenv('DDL_OPTIONS')
    if DDL_OPTIONS is None:
        print('DDL: DDL_OPTIONS is not set; need explicit init(options).')
    else:
        # ddl supported modes.
        ddl_supported_modes = ['b','n','r','m','p','c'] # Experimental Modes: 'd','x'
        ddl_options = os.environ['DDL_OPTIONS']
        ddl_opts_parts = ddl_options.split()

        mode_val = "r:" #default ddl mode
        mode_found=False
        for str1 in ddl_opts_parts:
            if ((not mode_found) and str1 == "-mode"):
                mode_found=True
            elif mode_found:
                mode_val = str1
                break

        mode_values = mode_val.split(":")
        ddl_mode = mode_values[0]
        for m in ddl_mode:
            if m not in ddl_supported_modes:
                sys.stderr.write('Incorrect DDL mode argument.\n')
                sys.exit(1)
else:
    world_size = 1
    local_size = 1
    world_rank = 0
    rank_local = 0



# The number of nodes (or hosts)
def num_hosts():
    return world_size // local_size

# rank runs from 0 to size (excl)
# uniquely identifies each parallel process
def rank():
    return world_rank

# size is the total number of GPUs (MPI processes)
# typically product of number of nodes and GPUs per node
def size():
    return world_size

# local_rank runs from 0 to the number of GPUs (excl) per node
# number of GPUs typically the same for each node, say 4
def local_rank():
    return rank_local

#Variable to keep track of the allreduce mode to use
#True == average and False == sum
_all_reduce_mode = True

# Use this function to toggle between allreduce modes
# True == average and False == sum
def set_allreduce_mode(average=True):
    global _all_reduce_mode
    _all_reduce_mode = average

# get the current allreduce mode
def get_allreduce_mode():
    return _all_reduce_mode

_tf_Session = tf.Session.__init__

def _config_proto(config):
    # Weird TF behavior: without allow_growth set here, TF will already
    # here allocate all memory on the GPU; even if later sessions use
    # a config that also sets allow_growth.
    config.gpu_options.allow_growth = True
    config.gpu_options.visible_device_list = str(local_rank())

def new_init(session_object, target='', graph=None, config=None):
    if config is None:
        config = tf.ConfigProto()

    _config_proto(config)
    _tf_Session(session_object, target, graph, config)

_tf_ConfigProto = tf.ConfigProto.__init__
def _new_ConfigProto(self, *args, **kwargs):
    _tf_ConfigProto(self, *args, **kwargs)
    _config_proto(self)

_orig_list_local_devices = device_lib.list_local_devices
def _new_list_local_devices(session_config=None):
    if session_config is None:
        session_config = tf.ConfigProto()
    _config_proto(session_config)
    return _orig_list_local_devices(session_config)

# Session redefined, if required
if mpi_init_status:
    tf.Session.__init__ = new_init
    tf.ConfigProto.__init__ = _new_ConfigProto
    device_lib.list_local_devices = _new_list_local_devices
    # Make sure eager context is initialized with our proto config
    conf = tf.ConfigProto()
    _config_proto(conf)
    context.context()._config = conf

ddl_MDR=None
def _init(options):
    """A function which initializes DDL.
    """
    # Dynamically load DDL TF library:
    global ddl_MDR
    if ddl_MDR is not None:
        raise RuntimeError('DDL has already been initialized.')

    ddl_MDR = tf.load_op_library('ddl_tensorflow.so')

    dbg = True
    DDL_DEBUG = os.getenv('DDL_DEBUG')
    if DDL_DEBUG is None:
        dbg = False

    # Initialize DDL:
    with tf.Session() as sess:
        sess.run(ddl_MDR.init(local_rank(), mode = options, dbg=dbg))

    # Echo all info so far using our own API:
    # mpi info and assigned GPU:
    print('DDL: rank: {}, size: {}, gpuid: {}, hosts: {}'.format(
        rank(), size(), local_rank(), num_hosts()))

# When building multiple graphs, possibly interleaved, we must keep
# track of the last Variable created per graph!
# For now we assume graphs are created in succession.

_prev_bcast_op = None
_prev_graph = None

# Creates broadcast node to share MPI root initial value among workers.
# Inserts control dependency on global prev_bcast_op under the covers.
# Returns initial value (Tensor) of root (when evaluated).
def _bcast(init_val):
    global _prev_bcast_op
    global _prev_graph

    # Make sure _prev_bcast_op and init_val are in same graph!
    if _prev_graph != tf.get_default_graph():
        # first time for this graph
        init_val = ddl_MDR.bcast(init_val)
    else:
        with tf.control_dependencies([_prev_bcast_op]):
            init_val = ddl_MDR.bcast(init_val)
    _prev_bcast_op = init_val
    _prev_graph = tf.get_default_graph()
    return init_val

# Intercept RefVariable constructor:
_tf_Var = RefVariable.__init__

# Our replacement:
# Insert a Bcast operator that will provide the initial value.
# Mind to enforce a consistent execution order across multiple instances.
# The _initializer_op of a RefVariable instance is adjusted to hold
# the bcast operator.
def newVar(self, *args, **kwargs):
    # Do normal action first:
    _tf_Var(self, *args, **kwargs)

    # Check for adjustment:
    if (not distribution_strategy_context.has_distribution_strategy() and
        'trainable' in kwargs and kwargs['trainable'] and
        'initial_value' in kwargs):

        # Hack to avoid InvalidArgumentError:
        # "The node 'init' has inputs from different frames..."
        # ref: https://github.com/tensorflow/tensorflow/issues/8604
        with tf.control_dependencies(None):
            self._initializer_op = _bcast(self._initializer_op.outputs[0])

# [Re]Enable injection of broadcast operators in Variable initialization.
# This will be the default action, unless disabled.
def enable_bcast():
    RefVariable.__init__ = newVar

# Disable injection of broadcast operators in Variable initialization.
def disable_bcast():
    RefVariable.__init__ = _tf_Var

# Maybe have function that broadcasts init value for all variables?

# One big AllReduce over all grads.
def _allreduce_n(grads, average=get_allreduce_mode(), device_dense='', device_sparse=''):
    #with tf.device('/gpu:0'):
    return ddl_MDR.all_reduce_n(grads, op='avg' if average else 'sum')

# Reduces gradients in grads_and_vars list.

def _grads_reduce_one(grads_and_vars, average=get_allreduce_mode()):
    # Unzip the list of tuples:
    grads, vars = zip(*grads_and_vars)
    # One big AllReduce over all grads; zip again with the weights:
    return zip(_allreduce_n(grads, average), vars)

def _grads_reduce_two(grads_and_vars, average=get_allreduce_mode()):

    divider0 = len(grads_and_vars)/2;
    grads_and_vars0 = grads_and_vars[:divider0]
    grads_and_vars1 = grads_and_vars[divider0:]

    return _grads_reduce_one(grads_and_vars0,average) + _grads_reduce_one(grads_and_vars1,average)

# Default ddl_group_size to a value that performs well on most HPM models
ddl_group_size = 10000000
ddl_group_size_env = os.getenv('DDL_GROUP_SIZE')
if ddl_group_size_env and ddl_group_size_env.isdigit():
    ddl_group_size = int(ddl_group_size_env)

ddl_sync_method = 'default'
ddl_sync_method_env = os.getenv('DDL_SYNC_METHOD')
if ddl_sync_method_env:
    ddl_sync_method = ddl_sync_method_env

if rank()==0:
    print('DDL: Execution Mode={}.'.format('Eager' if tf.executing_eagerly() else 'Graph'))
    print('DDL: DDL_GROUP_SIZE={}.'.format(ddl_group_size))
    print('DDL: DDL_SYNC_METHOD={}.'.format(ddl_sync_method))

def _get_tensor_size(g):
    if hasattr(g, 'dense_shape'):
        tensor_size = g.dense_shape.get_shape().num_elements()
    else:
        tensor_size = g.get_shape().num_elements()
    return tensor_size

#Minsik: these two functions are two different styles to group gradients
#both are experimental now, but we use the first one with a huge ddl_group_size
#to fallback onto the single allreduce behavior.
#1. group until the collected size is larger than ddl_group_size
def _grads_reduce_by_group(grads_and_vars, average=get_allreduce_mode()):

    cur_grads_size = 0
    cur_grads_vars = []
    ret_grads_vars = []

    for (g, v) in grads_and_vars:
        tensor_size = _get_tensor_size(g)

        #if the current size is too small or adding a new is OK
        if(cur_grads_size+tensor_size < ddl_group_size or tensor_size < 8192):
            cur_grads_size  +=  tensor_size
            cur_grads_vars.append([g, v])
        #else allreduce
        else:
            if not ret_grads_vars:
                ret_grads_vars += _grads_reduce_one(cur_grads_vars, average)
            else:
                with tf.control_dependencies([ret_grads_vars[-1][0]]):
                    ret_grads_vars += _grads_reduce_one(cur_grads_vars, average)

            #the current one needs to be remembered
            cur_grads_size = tensor_size
            cur_grads_vars = [(g, v)]

    #for any residue
    if cur_grads_size >0:
        if not ret_grads_vars:
            ret_grads_vars += _grads_reduce_one(cur_grads_vars, average)
        else:
            with tf.control_dependencies([ret_grads_vars[-1][0]]):
                ret_grads_vars += _grads_reduce_one(cur_grads_vars, average)

    return ret_grads_vars

def _grads_reduce_by_group_no_dep(grads_and_vars, average=get_allreduce_mode()):

    cur_grads_size = 0
    cur_grads_vars = []
    ret_grads_vars = []

    for (g, v) in grads_and_vars:
        tensor_size = _get_tensor_size(g)

        #if the current size is too small or adding a new is OK
        if(cur_grads_size+tensor_size < ddl_group_size or tensor_size < 8192):
            cur_grads_size  +=  tensor_size
            cur_grads_vars.append([g, v])
        #else allreduce
        else:
            ret_grads_vars += _grads_reduce_one(cur_grads_vars, average)

            #the current one needs to be remembered
            cur_grads_size = tensor_size
            cur_grads_vars = [(g, v)]

    #for any residue
    if cur_grads_size >0:
        ret_grads_vars += _grads_reduce_one(cur_grads_vars, average)

    return ret_grads_vars

#2. process any tensor larger than ddl_group_size individually
def _grads_reduce_by_size(grads_and_vars, average=get_allreduce_mode()):

    small_grads_size = 0
    small_grads_vars = []
    ret_grads_vars = []

    for (g, v) in grads_and_vars:
        tensor_size = _get_tensor_size(g)

        #if the current one is too small, keep adding
        if(tensor_size < ddl_group_size) :
            small_grads_vars.append([g, v])
            small_grads_size += tensor_size
        #else do allreduce
        else :
            if not ret_grads_vars:
                ret_grads_vars += _grads_reduce_one([(g,v)], average)
            else:
                with tf.control_dependencies([ret_grads_vars[-1][0]]):
                    ret_grads_vars += _grads_reduce_one([(g,v)], average)

        if small_grads_size > ddl_group_size:
            if not ret_grads_vars:
                ret_grads_vars += _grads_reduce_one(small_grads_vars, average)
            else:
                with tf.control_dependencies([ret_grads_vars[-1][0]]):
                    ret_grads_vars += _grads_reduce_one(small_grads_vars, average)

            small_grads_size = 0
            small_grads_vars = []

    #for all small ones
    if small_grads_vars:
        with tf.control_dependencies([ret_grads_vars[-1][0]]):
            ret_grads_vars += _grads_reduce_one(small_grads_vars, average)

    return ret_grads_vars

def _grads_reduce_by_size_no_dep(grads_and_vars, average=get_allreduce_mode()):
    if grads_and_vars is None:
        return []
    small_grads_size = 0
    small_grads_vars = []
    ret_grads_vars = []

    for (g, v) in grads_and_vars:
        tensor_size = _get_tensor_size(g)

        #if the current one is too small, keep adding
        if tensor_size < ddl_group_size :
            small_grads_vars.append((g,v))
            small_grads_size += tensor_size
        #else do allreduce
        else :
            big_grads_vars = [(g,v)]
            ret_grads_vars += _grads_reduce_one(big_grads_vars, average)

        if small_grads_size > ddl_group_size:
            ret_grads_vars += _grads_reduce_one(small_grads_vars, average)

            small_grads_size = 0
            small_grads_vars = []

    #for all small ones
    if small_grads_vars:
        ret_grads_vars += _grads_reduce_one(small_grads_vars, average)

    return ret_grads_vars

_grads_reduce = _grads_reduce_by_size_no_dep

def pack_tensors_by_group_size(tower_grads, max_elements):
    ranges = []
    singles = []
    first = 0
    last  = 0
    accumulated_size = 0
    gv_list = tower_grads[0]
    # DDL only support one tower per process
    assert len(tower_grads) == 1

    def store_index(singles_list, ranges_list):
        if accumulated_size != 0:
            if first == last:
                singles_list.append(first)
            else:
                ranges_list.append([first, last])

    for idx, (g, _) in enumerate(tower_grads[0]):
        if (accumulated_size + g.shape.num_elements() > max_elements):
            store_index(singles, ranges)
            first = idx
            accumulated_size = g.shape.num_elements()
        else:
            accumulated_size += g.shape.num_elements()
        last = idx
    store_index(singles, ranges)

    packing = {}
    if ranges:
        new_gv_list = []
        for r in ranges:
            key = '%d:%d' % (0, len(new_gv_list))
            new_gv_list.append((cross_device_utils_lib.pack_range(key, packing, gv_list, r),
                                'packing_var_placeholder'))
        for i in singles:
            new_gv_list.append(gv_list[i])
        return [new_gv_list], packing
    else:
        return tower_grads, None

def _aggregate_gradients_using_ddl(tower_grads):
  """Aggregate gradients using ddl allreduce."""

  agg_all_g_and_v = []
  for single_g_and_v in zip(*tower_grads):
    single_grads = [g for g, _ in single_g_and_v]

    agg_grads = []
    assert len(single_grads) == 1
    tensor = single_grads[0]
    agg_grads.append(ddl_MDR.all_reduce(tensor))

    agg_all_g_and_v.append(
        [(g, v) for g, (_, v) in zip(agg_grads, single_g_and_v)])

  agg_all_g_and_v = list(zip(*agg_all_g_and_v))

  return agg_all_g_and_v

def _dist_strategy_batch_all_reduce(self, aggregation, per_device_values):
    """All-reduce across all workers in a batch."""
    if cross_device_ops_lib.context.executing_eagerly():
        raise ValueError(
            "Eager execution with collective ops is not supported yet.")

    cross_device_ops_lib.logging.log_first_n(
        cross_device_ops_lib.logging.INFO, "DDL Collective All-reduce invoked with batches size = %d, "
                      "num_workers = %d" % (len(per_device_values), self._num_workers), 10)

    grouped_by_tower = cross_device_ops_lib._group_value_by_device(per_device_values)

    device_grad_packs, tensor_packing = pack_tensors_by_group_size(grouped_by_tower, ddl_group_size)

    reduced = _aggregate_gradients_using_ddl(device_grad_packs)

    reduced = cross_device_utils_lib.unpack_small_tensors(reduced, tensor_packing)

    return cross_device_ops_lib._ungroup_and_make_mirrored(
        reduced,
        per_device_values[0].devices,
        aggregation,
        num_between_graph_workers=self._num_workers)

def parse_cluster_config():
    ddl_host_list = os.getenv('DDL_HOST_LIST')
    ddl_host_port = os.getenv('DDL_HOST_PORT')
    if ddl_host_list and ddl_host_port:
        port = int(ddl_host_port)
        host_list = [None] * size()
        for host in ddl_host_list.split(';'):
            hostname = host.split(':')[0]
            rank_list = host.split(':')[1]
            offset = 0
            for rank_id in rank_list.split(','):
                host_list[int(rank_id)] = hostname + ':' + str(port + offset)
                offset += 1
        tf_config = '{"cluster": {"worker": %s}, "task": {"index": %d, "type": "worker"}}' % (json.dumps(host_list), rank())
        os.environ['TF_CONFIG'] = tf_config

# Intercept apply_gradients function:
from tensorflow.python.training import optimizer

#Minsik: keras support
keras_init_status = 'keras' in sys.modules

if mpi_init_status:
    if DDL_OPTIONS is None:
        if keras_init_status:
            raise RuntimeError('Could not initialize DDL with Keras. Run this program with -x DDL_OPTION="...".')
        else:
            # User must explicitly call API functions; no override.
            print('DDL: Expect explicit API calls.')
            init = _init
            bcast = _bcast
            allreduce_n = _allreduce_n
            grads_reduce = _grads_reduce
    else:
        # User indicates init should happen at import-time, i.e., now.
        _init(DDL_OPTIONS)

        # Redefine:
        RefVariable.__init__ = newVar

        if keras_init_status:
            if rank()==0:
                print('DDL: Enable Keras Support.')
            _tf_gradients = tf.gradients
            # See: tensorflow/python/ops/gradients_impl.py
            def new_gradients(ys, xs, grad_ys=None, name="gradients",
                              colocate_gradients_with_ops=False,
                              gate_gradients=False,
                              aggregation_method=None,
                              stop_gradients=None):
                grads = _tf_gradients(ys, xs, name=name,
                                      colocate_gradients_with_ops=colocate_gradients_with_ops,
                                      gate_gradients=gate_gradient,
                                      aggregation_method=aggregation_method,
                                      stop_gradients=stop_gradients)
                return _allreduce_n(grads, True)

            tf.gradients = new_gradients
        else:
            _tf_Opt_apply = optimizer.Optimizer.apply_gradients

            # Note: cannot create control dependencies on existing nodes!
            # Nodes once created are immutable.

            # Alternative that uses the new all_reduce_n node:
            def new_apply_gradients_flat(self, grads_and_vars, global_step=None, name=None):
              if ddl_sync_method == 'delayed':
                vW_list = [v for v in tf.trainable_variables()]
                vW_list.sort(key = lambda tnsr : tnsr.name)
                gs, vs = zip(*grads_and_vars)
                with tf.control_dependencies(gs):
                  event = ddl_MDR.wait(grads_and_vars[0][0])  # first arg pass through tensor for dependencies
                with tf.control_dependencies([event]):
                  ag = _tf_Opt_apply(self, grads_and_vars, global_step, name)
                with tf.control_dependencies([ag]):
                  tsx = ddl_MDR.all_reduce_async(event,vW_list)
                with tf.control_dependencies([tsx]):
                  ts = tf.identity(tsx)
                return ts
              elif not distribution_strategy_context.has_distribution_strategy():
                grads_and_vars = _grads_reduce(grads_and_vars, average=get_allreduce_mode())
              return _tf_Opt_apply(self, grads_and_vars, global_step, name)

            # Redefine:
            optimizer.Optimizer.apply_gradients = new_apply_gradients_flat

            # Reassign keras.backend.gradients to call DDL's allreduce function
            from tensorflow.python.keras import backend as K

            _tf_gradients = K.gradients

            def new_gradients (loss, variables):
                grads = _tf_gradients(loss, variables)
                return _allreduce_n(grads, True)

            K.gradients = new_gradients

            # Overwrite CollectiveAllReduceStrategy allreduce with DDL Allreduce
            cross_device_ops_lib.CollectiveAllReduce._batch_all_reduce = _dist_strategy_batch_all_reduce

            # Overwrite estimator to work with TF_CONFIG set but without distribution strategy
            from tensorflow_estimator.python.estimator import run_config
            _orig_init_distributed_setting_from_environment_var = run_config.RunConfig._init_distributed_setting_from_environment_var
            def _new_init_distributed_setting_from_environment_var(self, tf_config):
                _orig_init_distributed_setting_from_environment_var(self, {})
            run_config.RunConfig._init_distributed_setting_from_environment_var = _new_init_distributed_setting_from_environment_var

            # Setup TF_CONFIG for distribution strategy
            parse_cluster_config()

else:
    def raiseErr(*args):
        raise RuntimeError('Could not initialize DDL. Run this program using ddlrun.')

    init = raiseErr
    bcast = raiseErr
    allreduce_n = raiseErr
    grads_reduce = raiseErr


from tensorflow.python.keras import backend as K
from tensorflow.python.keras.callbacks import Callback
import numpy as np

class DDLCallback(Callback):
  """
  When using DDL this callback should usually be first in the Callback list.
  """

  def __init__(self):
      super(DDLCallback, self).__init__()

  def on_train_begin(self, logs=None):
      self.verbose = self.params['verbose']

  def on_epoch_end(self, epoch, logs=None):
      logs = logs or {}
      reduced_logs = {}
      for metric, value in sorted(logs.items()):
          pyddl.allreduce(np_value, 1, pyddl.DDL_TYPE_FLOAT, pyddl.DDL_OP_AVERAGE)
          np_value = np.array([value], dtype=np.float32)
          reduced_logs[metric] = np_value[0]

      if self.verbose:
          print("")
      for metric, value in reduced_logs.items():
          if self.verbose:
            print("DDL Synchronized %s: %s" % (str(metric), str(value)))
          logs[metric] = value

def get_global_variable_bcast_op(vars=None):
  """
  Returns group of tensorflow operations for broadcasting all global variables
  """

  bcast_op = None
  ops = []

  if vars is None:
    vars = tf.global_variables()
  for var in vars:
    with tf.control_dependencies(bcast_op):
      bcast_op = [tf.assign(var, ddl_MDR.bcast(var))]
    ops.append(*bcast_op)

  return tf.group(*ops)

class DDLGlobalVariablesCallback(Callback):
    """
    DDL Callback that will broadcast all global variables after initialization.
    This should usually be the last callback.
    """

    def __init__(self):
        super(DDLGlobalVariablesCallback, self).__init__()

    def on_train_begin(self, logs=None):
        vars = None
        if tf.executing_eagerly():
          vars = self.model.variables
        bcast_group = get_global_variable_bcast_op(vars)
        if not tf.executing_eagerly():
            K.get_session().run(bcast_group)

class DDLGlobalVariableHook (tf.train.SessionRunHook):
    """
    DDL SessionRunHook that will add ops to broadcast all global
        variables. The ops are added before the graph is finalized
        (in begin function) and ran after creating the session.
        This is because we cannot add ops after the graph is finalized.

    """
    def __init__(self):
        super(DDLGlobalVariableHook, self).__init__()
        self.bcast_op = None

    def after_create_session(self, session, coord):
        session.run(self.bcast_op)

    def begin(self):
        self.bcast_op = get_global_variable_bcast_op()
