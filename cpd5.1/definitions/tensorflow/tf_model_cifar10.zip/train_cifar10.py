import os
import tarfile
from six.moves import cPickle
import argparse
import json

import tensorflow as tf
import numpy as np
from tensorflow.keras import layers, models
from tensorflow.keras.optimizers import Adam

from emetrics import EMetrics


def get_data_path():
  default_root = os.getenv("DATA_DIR")
  download_root = os.getenv("WMLA_USER_DATA_DIR", "")
  download_file = os.getenv("WMLA_USER_DATA_FILES", "")

  if os.path.exists(default_root + "/batches.meta"):
    root_path = default_root
  elif os.path.exists(default_root + "/cifar-10-python.tar.gz"):
    root_path = default_root
    data_file = default_root + "/cifar-10-python.tar.gz"
  elif os.path.exists(download_file):
    root_path = download_root
    data_file = download_file
  else:
    raise RuntimeError("can not find required data set")

  if os.path.exists(root_path + "/batches.meta"):
    return root_path
  else:
    tarfile.open(data_file).extractall(root_path)
    return root_path + "/cifar-10-batches-py"


def load_batch(fpath, label_key='labels'):
  with open(fpath, 'rb') as f:
    d = cPickle.load(f, encoding='bytes')
    d_decoded = {}
    for k, v in d.items():
      d_decoded[k.decode('utf8')] = v
    d = d_decoded
  data = d['data']
  labels = d[label_key]

  data = data.reshape(data.shape[0], 3, 32, 32)
  return data, labels


def load_data():
  path = get_data_path()

  num_train_samples = 50000
  x_train = np.empty((num_train_samples, 3, 32, 32), dtype='uint8')
  y_train = np.empty((num_train_samples,), dtype='uint8')
  for i in range(1, 6):
    fpath = os.path.join(path, 'data_batch_' + str(i))
    (x_train[(i - 1) * 10000:i * 10000, :, :, :],
     y_train[(i - 1) * 10000:i * 10000]) = load_batch(fpath)

  fpath = os.path.join(path, 'test_batch')
  x_test, y_test = load_batch(fpath)

  y_train = np.reshape(y_train, (len(y_train), 1))
  y_test = np.reshape(y_test, (len(y_test), 1))

  x_train = x_train.transpose(0, 2, 3, 1)
  x_test = x_test.transpose(0, 2, 3, 1)

  return (x_train, y_train), (x_test, y_test)

def get_model():
  model = models.Sequential()
  model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)))
  model.add(layers.MaxPooling2D((2, 2)))
  model.add(layers.Conv2D(64, (3, 3), activation='relu'))
  model.add(layers.MaxPooling2D((2, 2)))
  model.add(layers.Conv2D(64, (3, 3), activation='relu'))

  model.add(layers.Flatten())
  model.add(layers.Dense(64, activation='relu'))
  model.add(layers.Dense(10, activation='softmax'))

  model.summary()
  return model

def get_learning_rate(lr):
  try:
    with open("config.json", 'r') as f:
        json_obj = json.load(f)
    learning_rate = float(json_obj["learning_rate"])
    print('use generated learning_rate={}'.format(learning_rate))
  except:
    learning_rate = lr
    print('use configured learning_rate={}'.format(lr))
  return learning_rate

class RecordMetrcs(tf.keras.callbacks.Callback):
  def __init__(self):
    self.em = EMetrics.open(os.getenv("SUBID"))
    self.test_steps = 0
   
  def on_epoch_end(self, epoch, logs=None):
    train_metrics = dict()
    test_metrics = dict()
    for name, value in logs.items():
      if name.startswith("val_"):
        test_metrics[name] = value
      else:
        train_metrics[name] = value
    self.em.record(EMetrics.TRAIN_GROUP, epoch, train_metrics)
    self.em.record(EMetrics.TEST_GROUP, epoch, test_metrics)

  def on_train_end(self, logs=None):
    self.em.close()

def train(lr, epochs, batch_size):
  (train_images, train_labels), (test_images, test_labels) = load_data()
  train_images, test_images = train_images / 255.0, test_images / 255.0

  optimizer = Adam(learning_rate=get_learning_rate(lr))
  model = get_model()
  model.compile(optimizer=optimizer,
                loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                metrics=['accuracy'])

  history = model.fit(train_images, train_labels, epochs=epochs, batch_size=batch_size, callbacks=[RecordMetrcs()],
                      validation_data=(test_images, test_labels))
  print("training history: ", history.history)

  test_loss, test_acc = model.evaluate(test_images,  test_labels, verbose=2)
  print("test_loss={}, test_acc={}".format(test_loss, test_acc))

  model_path = os.getenv("RESULT_DIR", "/tmp") + "/model"
  tf.saved_model.save(model, model_path)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--batch-size', type=int, default=64)
    args = parser.parse_args()
    print("Training with arguments: ", args)

    train(args.lr, args.epochs, args.batch_size)

if __name__ == '__main__':
    main()

